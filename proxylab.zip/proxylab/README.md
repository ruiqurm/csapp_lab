
# lab说明
这个lab要求我们实现一个代理服务器，只需要处理GET请求即可。我们的代理服务器需要同时能接受一个HTTP请求和发送一个HTTP请求。

## 目前进度

完成了lab，但是有一些小细节没有修改：

* 没有异常处理
* 无法处理uri上不带host的情况
* LRU 哈希表没写

## 测试
lab提供了自动打分的`driver.sh`。但是在`wsl`环境下是用不了的，可以在ubuntu的虚拟机环境上使用。此外，如果是比较新版本的`ubuntu`，`/usr/bin/python`是没有的，需要把`/nop-server.py`里的第一行改为`#!/usr/bin/python3`

自己测试的时候，有几种可选的方式：

* 显式地把代理地址写在uri里。例如` http://localhost:15214/localhost:15213/home.html` 。其中15214是代理服务器。

* `curl -v --proxy`

  例如：` curl -v --proxy http://localhost:15214 http://localhost:15213/home.html`

* 使用`netcat`

  ```
   nc localhost 15213
   GET http://www.cmu.edu/hub/index.html HTTP/1.0
   
   Host: www.cmu.edu
   
  ```

使用`netcat`如果不手动断开连接，就会一直连着服务器。对于`lab2`，可以测试被`netcat`占用时能否响应。

## hint

* 可以随意修改文件、添加文件，修改`makefile`
* 

# proxy lab

## Part 1

大体的框架是：

* 等待请求(`Accept`)
* 处理`uri`
* 构建新头
* 连接目标服务器
* 写入目标服务器
* 关闭连接

具体的实现可以参考书上`tiny`服务器+客户端；

需要仔细处理的主要是处理`uri`和构建`header`。

### `parse_uri`

不同形式地访问服务器，uri也会相应不同。至少有以下几种形式：

* `http://localhost:15214/localhost:15213/home.html`

* `http://localhost/localhost:15213/home.html`(无端口)
* `/localhost:15213/home.html`
* `/localhost/home.html`(无端口)
* `/home.html`(没有host)

目前只处理了前4种情况，对于没有host的相对uri。例如`/home.html`，就会报错。

```c
void parse_uri(char* uri,char* host,char*path,int *port){
    //下面可能会改动uri
    char* ptr = strstr(uri,"//");
    char c_temp;//用于复原uri
    if (ptr!=NULL){
        // uri形如:http://localhost:15213/home.html
            ptr += 2; 
            char* portpos = strstr(ptr, ":");
            if (portpos!=NULL){// localhost:15213/home.html
                *portpos = '\0' ;
                sscanf(ptr, "%s", host);
                sscanf(portpos+1, "%d%s", port, path);
            }else{// localhost/home.html
                char *split = strstr(ptr,"/");
                *split = '\0';
                strcpy(host,ptr);
                *split = '/';
                strcpy(path,split);
            }
        return ;
    }
    ptr = uri;
    if (ptr[0]=='/'){
        ptr+=1;
        char* portpos = strstr(ptr, ":");
        if (portpos!=NULL){// /localhost:15213/home.html
            c_temp = *portpos;
            *portpos = '\0' ;
            sscanf(ptr, "%s", host);
            sscanf(portpos+1, "%d%s", port, path);
            *portpos = c_temp;
            return; 
        }else{// localhost/home.html
            char *split = strstr(ptr,"/");
            *split = '\0';
            strcpy(host,ptr);
            printf("host: %s\n",host);
            *split = '/';
            strcpy(path,split);
            return;
        }
    }
}
```



### 构建新头

这一部分

### 异常处理

对于`csapp.c`的，某些内置函数，例如`Open_clientfd`等，如果失败了，就会直接`exit(0)`。由于这边开的是线程，这样直接整个主程序就退出了。

可以参考[七 PROXY LAB](https://www.jianshu.com/p/a501d0c2f131)  Part 2.1的解决方案：

![](https://upload-images.jianshu.io/upload_images/10803273-9283823830fd4755.png?imageMogr2/auto-orient/strip|imageView2/2/w/677/format/webp)

![](https://upload-images.jianshu.io/upload_images/10803273-1348de739e273043.png?imageMogr2/auto-orient/strip|imageView2/2/w/631/format/webp)



## Part 3

LRU的一种比较简单的实现是用双端链表+Hash Map.